


# Nibble Social Media App UI

Built with example project referece: Furniture Shop UI by abuanwar072


Work In Progress-

I designed a social media app for sharing food pictures between friends, similar to Instagram. I planned to add features to show a specific details page about the restaurants that are tagged in the posts, a rating system, and a reservations features as well. I also added a notifications center, a feature to see what posts the user has saved, user's profile feed, etc.

I first designed the wireframes in Figma (files are included in project folder) and started to build the UI with SwiftUI, only partially finished- still planning to add camera/photo picker feature, incorporate JSON data set, etc.

