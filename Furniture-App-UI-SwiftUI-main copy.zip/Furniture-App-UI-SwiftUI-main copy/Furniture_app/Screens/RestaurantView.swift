//
//  RestaurantView.swift
//  Furniture_app
//
//  Created by Lee Jean You on 5/6/22.
//

import SwiftUI

struct RestaurantView: View {
    var body: some View {
      ScrollView{
      VStack{
        HStack {
          NavigationLink(destination:MyProfile()){
            Button(action: {}) {
              Image("back-icon")
                .padding()
            }}
          Spacer()
          
          VStack{
            Text("Udon St.Marks")
              .font(.footnote)
              .fontWeight(.semibold)
            Text("Japanese")
              .font(.caption2)
              .foregroundColor(Color.gray)
          }
          
          Spacer()
          
          NavigationLink(destination:NotificationView()){
            Button(action: {}) {
              Image("save-icon")
                .resizable()
                .scaledToFit()
                .frame(width: 15)
                .padding()
            }}
        }
        .padding(.horizontal, 40.0)
        Image("udon-st-marks")
          .resizable()
          .scaledToFit()
          .frame(width:400,height:200)
        
        VStack{
          Text("Information")
            .font(.subheadline)
            .fontWeight(.medium)
            .multilineTextAlignment(.leading)
          HStack{
            Text("Address")
              .font(.caption)
              .fontWeight(.medium)
            Text("11 St Marks Pl, New York, NY 10003")
              .font(.caption2)
          }
          .padding(.top)
          HStack{
            Text("Phone")
              .font(.caption)
              .fontWeight(.medium)
            Text("(332) 209-0533")
              .font(.caption2)
          }
          HStack{
            Text("Hours")
              .font(.caption)
              .fontWeight(.medium)
            VStack{
            Text("Monday-Friday : 4 PM-10PM")
              .font(.caption2)
              Text("Saturday-Sunday:  12PM-10PM")
                .font(.caption2)
            }}

          VStack{
            Text("Posts")
              .font(.subheadline)
              .fontWeight(.medium)
              .padding(.vertical)
            VStack{
              HStack{
                Image("1")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80)
                Image("2")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80)
                Image("3")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80)
                
              }
              HStack{
                Image("1")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80)
                Image("2")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80)
                Image("3")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80)
                
              }
              HStack{
                Image("1")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80)
                Image("2")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80)
                Image("3")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80)
                
              }
            }
          }
          .padding(.bottom)
        }
        .padding(.top)
      }
      }
      .padding(.horizontal)
    }}

struct RestaurantView_Previews: PreviewProvider {
    static var previews: some View {
        RestaurantView()
    }
}
