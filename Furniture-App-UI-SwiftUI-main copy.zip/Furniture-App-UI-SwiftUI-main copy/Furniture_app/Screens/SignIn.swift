//
//  SignIn.swift
//  Furniture_app
//
//  Created by Lee Jean You on 5/6/22.
//

import SwiftUI

struct SignIn: View {
    var body: some View {
      ZStack{
        Color(#colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1))
          .ignoresSafeArea()
      VStack{
        Image("plates-icon2")
          .resizable()
          .padding(.bottom)
          .scaledToFit()
          .frame(width:70)
        Image("nibble-logo2")
          .resizable()
          .scaledToFit()
          .frame(width: 100)
        HStack{
          Text("Username")
          TextField ("Username (email address)",text)
        }
        Hstack{
          Text("Password")
        }
      }
      }
    }}

struct SignIn_Previews: PreviewProvider {
    static var previews: some View {
        SignIn()
    }
}
