//
//  MyLikes.swift
//  Furniture_app
//
//  Created by Lee Jean You on 5/6/22.
//

import SwiftUI

struct MyLikes: View {
    var body: some View {
      ScrollView{
        VStack{
        HStack {
          NavigationLink(destination:MyProfile()){
            Button(action: {}) {
              Image("back-icon")
                .padding()
            }}
          Spacer()
          
          Text("My Likes")
            .font(.subheadline)
            .fontWeight(.medium)
          
          
          Spacer()
          
          NavigationLink(destination:MyProfile()){
            Button(action: {}) {
              Image("myprofile")
                .resizable()
                .scaledToFill()
                .frame(width: 35, height: 35)
                .clipShape(Circle())
            }
          }
        }
        .padding([.leading, .bottom, .trailing])
          HStack{
            Image("1")
              .resizable()
              .scaledToFit()
              .frame(width:80)
            Image("2")
              .resizable()
              .scaledToFit()
              .frame(width:80)
            Image("3")
              .resizable()
              .scaledToFit()
              .frame(width:80)
          }
          HStack{
            Image("1")
              .resizable()
              .scaledToFit()
              .frame(width:80)
            Image("2")
              .resizable()
              .scaledToFit()
              .frame(width:80)
            Image("3")
              .resizable()
              .scaledToFit()
              .frame(width:80)
          }
          HStack{
            Image("1")
              .resizable()
              .scaledToFit()
              .frame(width:80)
            Image("2")
              .resizable()
              .scaledToFit()
              .frame(width:80)
            Image("3")
              .resizable()
              .scaledToFit()
              .frame(width:80)
          }
          HStack{
            Image("1")
              .resizable()
              .scaledToFit()
              .frame(width:80)
            Image("2")
              .resizable()
              .scaledToFit()
              .frame(width:80)
            Image("3")
              .resizable()
              .scaledToFit()
              .frame(width:80)
          }
          HStack{
            Image("1")
              .resizable()
              .scaledToFit()
              .frame(width:80)
            Image("2")
              .resizable()
              .scaledToFit()
              .frame(width:80)
            Image("3")
              .resizable()
              .scaledToFit()
              .frame(width:80)
          }
          .padding()
        }}
    }
}

struct MyLikes_Previews: PreviewProvider {
    static var previews: some View {
        MyLikes()
    }
}
