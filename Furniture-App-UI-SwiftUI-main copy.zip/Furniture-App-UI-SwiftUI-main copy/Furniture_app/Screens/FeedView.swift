//
//  FeedView.swift
//  Furniture_app
//
//  Created by Lee Jean You on 5/6/22.
//

import SwiftUI

struct FeedView: View {
    var body: some View {
        ScrollView{
          VStack{
          HStack {
            NavigationLink(destination:MyProfile()){
              Button(action: {}) {
                Image("home-icon")
                  .padding()
              }}
            Spacer()
            
            NavigationLink(destination:NotificationView()){
              Button(action: {}) {
                Image("notification-icon")
                  .resizable()
                  .scaledToFill()
                  .frame(width: 20, height: 20)
                  .padding()
              }}
            
            NavigationLink(destination:MyProfile()){
              Button(action: {}) {
                Image("myprofile")
                  .resizable()
                  .scaledToFill()
                  .frame(width: 35, height: 35)
                  .clipShape(Circle())
              }
            }}
            HStack{
              Image("friendprofile")
                .resizable()
                .scaledToFill()
                .frame(width: 25,height: 25)
                .clipShape(Circle())
              VStack{
              Text("myfriend123")
                  .font(.footnote)
                  .foregroundColor(Color(red: 0.042, green: 0.083, blue: 0.294))
                  .multilineTextAlignment(.leading)
                NavigationLink(destination:RestaurantView()){
                Text("Eataly Downtown")
                  .font(.caption2)
                  .fontWeight(.medium)
                  .foregroundColor(Color.black)
                  .multilineTextAlignment(.leading)
                }}
              Spacer()
              VStack{
              Image("filledstar-icon")
                .resizable()
                .scaledToFit()
                .frame(width:14)
                Text("13 Minutes Ago")
                  .font(.caption2)
                  .foregroundColor(Color.gray)
              }
            }
            .padding([.top, .leading, .trailing])

            Image("eataly-downtown")
              .resizable()
              .padding(.bottom)
              .scaledToFill()
              .frame(width:250,height: 350)
            HStack{
              Image("like-icon")
                .resizable()
                .scaledToFit()
                .frame(width:25)
              Image("comment-icon")
                .resizable()
                .scaledToFit()
                .frame(width:25)
              Spacer()
              Image("save-icon")
                .resizable()
                .scaledToFit()
                .frame(width:18)
            }
            .padding(.horizontal)
            HStack{
              Text("myfriend123")
                .font(.footnote)
                .fontWeight(.semibold)
              Spacer()
              Text("I love pasta")
                .font(.footnote)
            }
            .padding([.top, .leading, .trailing])
            HStack{
              Text("hello586")
                .font(.footnote)
                .fontWeight(.semibold)
              Spacer()
              Text("This looks amazing!")
                .font(.footnote)
            }
            .padding(.horizontal)
            HStack{
              Text("foodie222")
                .font(.footnote)
                .fontWeight(.semibold)
              Spacer()
              Text("I want pasta now")
                .font(.footnote)
            }
            .padding(.horizontal)
            HStack{
              Image("friendprofile2")
                .resizable()
                .scaledToFill()
                .frame(width: 25,height: 25)
                .clipShape(Circle())
              Text("myfriend123")
                .font(.footnote)
              Spacer()
              Image("filledstar-icon")
                .resizable()
                .scaledToFit()
                .frame(width:20)
            }

            .padding([.top, .leading, .trailing])
            Image("crownshy")
              .resizable()
              .scaledToFill()
              .frame(width:250,height: 350)
            
            HStack{
              Image("like-icon")
                .resizable()
                .scaledToFit()
                .frame(width:25)
              Image("comment-icon")
                .resizable()
                .scaledToFit()
                .frame(width:25)
              Spacer()
              Image("save-icon")
                .resizable()
                .scaledToFit()
                .frame(width:18)

            }
            
            .padding([.top, .leading, .trailing])
            
          }
          HStack() {
            BottomNavBarItem(image: Image("discover-icon-1"), action: {})
            BottomNavBarItem(image: Image("search-icon-1"), action: {})
            BottomNavBarItem(image: Image("upload2-icon-1"), action: {})
            BottomNavBarItem(image: Image("save-icon-1"), action: {})
            BottomNavBarItem(image: Image("reservations-icon-1"), action: {})
          }
          .padding()
          .background(Color.white)
          .clipShape(Capsule())
          .shadow(color: Color.blue.opacity(0.15), radius: 8, x: 2, y: 6)
        }
        .padding(.horizontal, 17.0)
    }
}

struct FeedView_Previews: PreviewProvider {
    static var previews: some View {
        FeedView()
    }
}
