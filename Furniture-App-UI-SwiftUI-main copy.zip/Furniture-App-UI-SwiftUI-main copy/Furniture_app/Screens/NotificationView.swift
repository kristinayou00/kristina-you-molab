//
//  NotificationView.swift
//  Furniture_app
//
//  Created by Lee Jean You on 5/6/22.
//

import SwiftUI

struct NotificationView: View {
    var body: some View {
      ScrollView{
        VStack{
          HStack{
            NavigationLink(destination:MyProfile()){
              Button(action: {}) {
                Image("back-icon")
                  .padding()
              }}
            Spacer()
            
            Text("Notification Center")
              .font(.subheadline)
              .fontWeight(.medium)
            
            
            Spacer()
            
            NavigationLink(destination:MyProfile()){
              Button(action: {}) {
                Image("myprofile")
                  .resizable()
                  .scaledToFill()
                  .frame(width: 35, height: 35)
                  .clipShape(Circle())
              }
            }
          }
          Divider()
          Text("New")
            .font(.footnote)
            .fontWeight(.medium)
            .multilineTextAlignment(.leading)
          HStack{
            Image("Profile")
              .resizable()
              .scaledToFit()
              .frame(width:35)
              .clipShape(Circle())
            Spacer()
            Text("friend111")
              .font(.caption2)
              .fontWeight(.semibold)
              .padding(.leading)
            Text("liked your post.")
              .font(.caption2)
              .multilineTextAlignment(.leading)
            Spacer()
            Image("eataly-downtown")
              .resizable()
              .scaledToFit()
              .frame(width:30,height:30)
          }
          .padding(.horizontal)
          
          HStack{
            Image("Profile")
              .resizable()
              .scaledToFit()
              .frame(width:35)
              .clipShape(Circle())
            Spacer()
            Text("friend111")
              .font(.caption2)
              .fontWeight(.semibold)
              .padding(.leading)
            Text("liked your post.")
              .font(.caption2)
              .multilineTextAlignment(.leading)
            Spacer()
            Image("eataly-downtown")
              .resizable()
              .scaledToFit()
              .frame(width:30,height:30)
          }
          .padding(.horizontal)
          HStack{
            Image("Profile")
              .resizable()
              .scaledToFit()
              .frame(width:35)
              .clipShape(Circle())
            Spacer()
            Text("friend111")
              .font(.caption2)
              .fontWeight(.semibold)
              .padding(.leading)
            Text("liked your post.")
              .font(.caption2)
              .multilineTextAlignment(.leading)
            Spacer()
            Image("eataly-downtown")
              .resizable()
              .scaledToFit()
              .frame(width:30,height:30)
          }
          .padding(.horizontal)
          Divider()
          
          Text("Last Week")
            .font(.caption)
            .fontWeight(.medium)
            .padding(.horizontal)

          Spacer()
            .padding(.vertical, 100.0)
          HStack() {
            NavigationLink(destination:HomeScreen()){
              BottomNavBarItem(image: Image("discover-icon-1"), action: {})}
            BottomNavBarItem(image: Image("search-icon-1"), action: {})
            BottomNavBarItem(image: Image("upload2-icon-1"), action: {})
            BottomNavBarItem(image: Image("save-icon-1"), action: {})
            BottomNavBarItem(image: Image("reservations-icon-1"), action: {})
          }
          .padding()
          .background(Color.white)
          .clipShape(Capsule())
          .padding(.horizontal)
          .shadow(color: Color.blue.opacity(0.15), radius: 8, x: 2, y: 6)
        }
      }
      .padding(.horizontal)
    }
}

struct NotificationView_Previews: PreviewProvider {
    static var previews: some View {
        NotificationView()
    }
}
