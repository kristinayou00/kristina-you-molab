//
//  MyProfile.swift
//  Furniture_app
//
//  Created by Lee Jean You on 5/6/22.
//

import SwiftUI

struct MyProfile: View {
    var body: some View {

      VStack{
        ScrollView{
        HStack {
          NavigationLink(destination:MyProfile()){
            Button(action: {}) {
              Image("home-icon")
                .padding()
            }}
          Spacer()
          
          NavigationLink(destination:NotificationView()){
            Button(action: {}) {
              Image("notification-icon")
                .resizable()
                .scaledToFill()
                .frame(width: 20, height: 20)
                .padding()
            }}
          
          NavigationLink(destination:MyProfile()){
            Button(action: {}) {
              Image(uiImage: #imageLiteral(resourceName: "myprofile"))
                .resizable()
                .scaledToFill()
                .frame(width: 35, height: 35)
                .clipShape(Circle())
            }
          }}
        
        .padding(.horizontal)
        
        HStack{
          Image("myprofile")
            .resizable()
            .scaledToFit()
            .frame(width: 100)
            .clipShape(Circle())
          VStack{
            Text("kjackson29")
              .font(.subheadline)
              .fontWeight(.regular)
              .multilineTextAlignment(.leading)
            Text("Kaya Jackson")
              .font(.caption)
              .fontWeight(.bold)
              .multilineTextAlignment(.leading)
            HStack{
              Text("48 Friends")
                .font(.footnote)

              Text("50 Posts")
                .font(.footnote)
            }}}
        .padding(.bottom)
            VStack{
            HStack{
              Image("1")
                .resizable()
                .scaledToFit()
                .frame(width:80, height:80)
              Image("2")
                .resizable()
                .scaledToFit()
                .frame(width:80, height:80)
              Image("3")
                .resizable()
                .scaledToFit()
                .frame(width:80, height:80)
            }
              HStack{
                Image("4")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80, height:80)
                Image("5")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80, height:80)
                Image("6")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80, height:80)
              }
              HStack{
                Image("7")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80, height:80)
                Image("8")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80, height:80)
                Image("9")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80, height:80)
              }
              HStack{
                Image("10")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80, height:80)
                Image("11")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80, height:80)
                Image("12")
                  .resizable()
                  .scaledToFit()
                  .frame(width:80, height:80)
              }

          }
        
        HStack() {
          BottomNavBarItem(image: Image("discover-icon-1"), action: {})
          BottomNavBarItem(image: Image("search-icon-1"), action: {})
          BottomNavBarItem(image: Image("upload2-icon-1"), action: {})
          BottomNavBarItem(image: Image("save-icon-1"), action: {})
          BottomNavBarItem(image: Image("reservations-icon-1"), action: {})
        }
        .padding()
        .background(Color.white)
        .clipShape(Capsule())
        .padding(.horizontal)
        .shadow(color: Color.blue.opacity(0.15), radius: 8, x: 2, y: 6)
      }

      }
    }}

struct MyProfile_Previews: PreviewProvider {
    static var previews: some View {
        MyProfile()
    }
}

